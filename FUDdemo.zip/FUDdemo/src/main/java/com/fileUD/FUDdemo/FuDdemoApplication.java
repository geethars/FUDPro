package com.fileUD.FUDdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FuDdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FuDdemoApplication.class, args);
	}

}
