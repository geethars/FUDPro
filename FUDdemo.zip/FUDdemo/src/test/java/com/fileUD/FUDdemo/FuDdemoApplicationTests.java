package com.fileUD.FUDdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuDdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
